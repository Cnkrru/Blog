<script setup>

</script>

<template>
<svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    stroke-width="2" 
    stroke-linecap="round" 
    stroke-linejoin="round">
    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>
    <line x1="8" y1="16" x2="8.01" y2="16"/>
    <line x1="12" y1="18" x2="12.01" y2="18"/>
    <line x1="16" y1="16" x2="16.01" y2="16"/>
</svg>
</template>

<style scoped>

</style>
