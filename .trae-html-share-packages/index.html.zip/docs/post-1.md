---
order: 1
title: 个人博客介绍
date: 2026-03-29
updated: 2026-08-08
category: 随笔
tags: [随笔]
history:
  - 2026-08-07 更新文章内容，部分功能替换或者移除，按照现在的情况写 
  - 2026-08-06 同步最新技术栈和功能特性
  - 2026-07-15 更新项目截图和架构说明
  - 2026-04-10 补充SEO和性能优化说明
description: 一个使用 Vue 3、Vite 等现代前端技术栈构建的个人博客项目，包含 Markdown 渲染、代码高亮、数学公式支持等功能，提供快速、优雅的写作和阅读体验。
keywords: 个人博客, Vue 3, Vite, 前端项目, Markdown, 代码高亮, 数学公式, 响应式设计
---
## 博客介绍
1. 该博客基于vue3
2. 使用vue插件来实现类似SSG的效果
---
### 简介

> 作者先前用过hexo，hugo这些SSG，后希望基于HTML，CSS，JavaScript自定义，实现部分功能后，转而用vue搭建，js也转为ts。

> 博客和其他SSG一样，自己只需要写markdown文章，引入markjs来实现md转HTML
---
### 第三方功能介绍

1. 不蒜子统计
2. 谷歌分析、百度分析、vercel分析
3. giscus评论
5. 天气API
6. IP地址API
7. 樱花雪花动态背景
---
### 联系方式

> 编辑于2026-03-30

> 作者：Cnkrru

> 联系方式：3253884026@qq.com
