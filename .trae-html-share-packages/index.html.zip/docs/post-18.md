---
order: 18
title: Frontend-giscus评论嵌入
date: 2026-08-11
category: 前端
tags: [前端]
description: 介绍前端组件：giscus评论的制作方法以及如何自定义CSS
keywords: frontend
---
## 制作方法
1. giscus介绍
    - giscus是GitHub上一款依赖GitHub的免费评论功能
    - 官网:[https://giscus.app/zh-CN](https://giscus.app/zh-CN)
2. 使用前提
    - 给GitHub对应仓库安装`giscus`APP
    - 在设置页面开启仓库对应的讨论功能
    - 在giscus官网填一下配置，生成一段js
    - 将生成的js导入自己的网站，部署上线即可
> 文档不太容易说明白，之后如果出视频讲解的话，会更新视频链接
---
## 代码
```javascript
<script src="https://giscus.app/client.js"
        data-repo="[在此输入仓库]"
        data-repo-id="[在此输入仓库 ID]"
        data-category="[在此输入分类名]"
        data-category-id="[在此输入分类 ID]"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="preferred_color_scheme"
        data-lang="zh-CN"
        crossorigin="anonymous"
        async>
</script>
```
> 上面是js脚本代码，需要你填配置来生成
---
## 自定义CSS样式
> 作者自定义CSS是去giscus的官方GitHub仓库找的css文件，复制到本地来修改了
> 以下两个是作者的樱粉风格主题giscus的亮暗CSS
- 亮色主题CSS
```css
/*! MIT License - Copyright (c) 2021 GitHub Inc. */

main {
  --color-prettylights-syntax-comment: #6e7781;
  --color-prettylights-syntax-constant: #0550ae;
  --color-prettylights-syntax-entity: #8250df;
  --color-prettylights-syntax-storage-modifier-import: #24292f;
  --color-prettylights-syntax-entity-tag: #116329;
  --color-prettylights-syntax-keyword: #cf222e;
  --color-prettylights-syntax-string: #0a3069;
  --color-prettylights-syntax-variable: #953800;
  --color-prettylights-syntax-brackethighlighter-unmatched: #82071e;
  --color-prettylights-syntax-invalid-illegal-text: #f6f8fa;
  --color-prettylights-syntax-invalid-illegal-bg: #82071e;
  --color-prettylights-syntax-carriage-return-text: #f6f8fa;
  --color-prettylights-syntax-carriage-return-bg: #cf222e;
  --color-prettylights-syntax-string-regexp: #116329;
  --color-prettylights-syntax-markup-list: #3b2300;
  --color-prettylights-syntax-markup-heading: #0550ae;
  --color-prettylights-syntax-markup-italic: #24292f;
  --color-prettylights-syntax-markup-bold: #24292f;
  --color-prettylights-syntax-markup-deleted-text: #82071e;
  --color-prettylights-syntax-markup-deleted-bg: #ffebe9;
  --color-prettylights-syntax-markup-inserted-text: #116329;
  --color-prettylights-syntax-markup-inserted-bg: #dafbe1;
  --color-prettylights-syntax-markup-changed-text: #953800;
  --color-prettylights-syntax-markup-changed-bg: #ffd8b5;
  --color-prettylights-syntax-markup-ignored-text: #eaeef2;
  --color-prettylights-syntax-markup-ignored-bg: #0550ae;
  --color-prettylights-syntax-meta-diff-range: #8250df;
  --color-prettylights-syntax-brackethighlighter-angle: #57606a;
  --color-prettylights-syntax-sublimelinter-gutter-mark: #8c959f;
  --color-prettylights-syntax-constant-other-reference-link: #0a3069;

  --color-btn-text: #333;
  --color-btn-bg: #fff;
  --color-btn-border: rgba(0, 0, 0, 0.12);
  --color-btn-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  --color-btn-inset-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.5);
  --color-btn-hover-bg: #f8f8f8;
  --color-btn-hover-border: rgba(0, 0, 0, 0.18);
  --color-btn-active-bg: #f0f0f0;
  --color-btn-active-border: rgba(0, 0, 0, 0.2);
  --color-btn-selected-bg: rgba(255, 192, 203, 0.15);

  --color-btn-primary-text: #333;
  --color-btn-primary-bg: rgba(255, 192, 203, 0.85);
  --color-btn-primary-border: rgba(255, 192, 203, 0.85);
  --color-btn-primary-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --color-btn-primary-inset-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.3);
  --color-btn-primary-hover-bg: rgba(255, 192, 203, 1);
  --color-btn-primary-hover-border: rgba(255, 192, 203, 1);
  --color-btn-primary-selected-bg: rgba(255, 192, 203, 0.9);
  --color-btn-primary-selected-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.08);
  --color-btn-primary-disabled-text: rgba(51, 51, 51, 0.4);
  --color-btn-primary-disabled-bg: rgba(255, 192, 203, 0.3);
  --color-btn-primary-disabled-border: rgba(255, 192, 203, 0.2);

  --color-action-list-item-default-hover-bg: rgba(0, 0, 0, 0.04);
  --color-segmented-control-bg: rgba(0, 0, 0, 0.04);
  --color-segmented-control-button-bg: #fff;
  --color-segmented-control-button-selected-border: rgba(0, 0, 0, 0.12);

  --color-fg-default: #333;
  --color-fg-muted: rgba(51, 51, 51, 0.5);
  --color-fg-subtle: rgba(51, 51, 51, 0.3);

  --color-canvas-default: rgba(255, 255, 255, 0.6);
  --color-canvas-overlay: rgba(255, 255, 255, 0.9);
  --color-canvas-inset: rgba(0, 0, 0, 0.02);
  --color-canvas-subtle: rgba(0, 0, 0, 0.02);

  --color-border-default: rgba(0, 0, 0, 0.08);
  --color-border-muted: rgba(0, 0, 0, 0.04);
  --color-neutral-muted: rgba(175, 184, 193, 0.2);

  --color-accent-fg: rgba(255, 192, 203, 1);
  --color-accent-emphasis: rgba(255, 192, 203, 1);
  --color-accent-muted: rgba(255, 192, 203, 0.3);
  --color-accent-subtle: rgba(255, 192, 203, 0.08);

  --color-success-fg: #1a7f37;
  --color-attention-fg: #9a6700;
  --color-attention-muted: rgba(212, 167, 44, 0.3);
  --color-attention-subtle: rgba(255, 255, 0, 0.06);
  --color-danger-fg: #cf222e;
  --color-danger-muted: rgba(255, 129, 130, 0.3);
  --color-danger-subtle: rgba(255, 0, 0, 0.06);

  --color-primer-shadow-inset: inset 0 1px 0 rgba(0, 0, 0, 0.04);
  --color-scale-gray-1: rgba(0, 0, 0, 0.04);
  --color-scale-blue-1: rgba(255, 192, 203, 0.1);
  --color-social-reaction-bg-hover: var(--color-scale-gray-1);
  --color-social-reaction-bg-reacted-hover: var(--color-scale-blue-1);
}

/* ========== macOS style overrides ========== */
.btn {
  border-radius: 10px !important;
  font-weight: 500 !important;
  letter-spacing: -0.1px;
  transition: background-color 0.12s ease, border-color 0.12s ease, transform 0.1s ease, box-shadow 0.12s ease !important;
}
.btn:hover {
  transform: translateY(-1px) !important;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06) !important;
}
.btn:active {
  transform: scale(0.97) !important;
}
.btn-primary {
  border-radius: 10px !important;
  font-weight: 600 !important;
}
.gsc-comment-box {
  border-radius: 14px !important;
  overflow: hidden !important;
}
.gsc-comment-box-textarea {
  border-radius: 12px !important;
  font-size: 14px !important;
  background: rgba(255, 255, 255, 0.55) !important;
  border-color: rgba(0, 0, 0, 0.08) !important;
}
.gsc-comment-box-textarea:focus {
  border-color: rgba(255, 192, 203, 0.5) !important;
  box-shadow: 0 0 0 3px rgba(255, 192, 203, 0.12) !important;
}
.gsc-comment {
  padding: 14px !important;
  border-radius: 12px !important;
  margin-bottom: 8px !important;
  background: rgba(255, 255, 255, 0.4) !important;
  border: 1px solid rgba(0, 0, 0, 0.04) !important;
}
.gsc-header {
  padding-bottom: 10px !important;
  border-bottom: 1px solid rgba(0, 0, 0, 0.06) !important;
  margin-bottom: 14px !important;
}
.gsc-timeline {
  gap: 14px !important;
}
.gsc-reactions-button {
  border-radius: 8px !important;
}
.gsc-social-reaction-summary-item {
  border-radius: 20px !important;
}
.Box, .flash {
  border-radius: 12px !important;
}
.form-control {
  border-radius: 10px !important;
}
</style>

```
- 暗色主题CSS
```css
/*! MIT License - Copyright (c) 2021 GitHub Inc. */
main {
  --color-prettylights-syntax-comment: #8b949e;
  --color-prettylights-syntax-constant: #79c0ff;
  --color-prettylights-syntax-entity: #d2a8ff;
  --color-prettylights-syntax-storage-modifier-import: #c9d1d9;
  --color-prettylights-syntax-entity-tag: #7ee787;
  --color-prettylights-syntax-keyword: #ff7b72;
  --color-prettylights-syntax-string: #a5d6ff;
  --color-prettylights-syntax-variable: #ffa657;
  --color-prettylights-syntax-brackethighlighter-unmatched: #f85149;
  --color-prettylights-syntax-invalid-illegal-text: #f0f6fc;
  --color-prettylights-syntax-invalid-illegal-bg: #8e1519;
  --color-prettylights-syntax-carriage-return-text: #f0f6fc;
  --color-prettylights-syntax-carriage-return-bg: #b62324;
  --color-prettylights-syntax-string-regexp: #7ee787;
  --color-prettylights-syntax-markup-list: #f2cc60;
  --color-prettylights-syntax-markup-heading: #1f6feb;
  --color-prettylights-syntax-markup-italic: #c9d1d9;
  --color-prettylights-syntax-markup-bold: #c9d1d9;
  --color-prettylights-syntax-markup-deleted-text: #ffdcd7;
  --color-prettylights-syntax-markup-deleted-bg: #67060c;
  --color-prettylights-syntax-markup-inserted-text: #aff5b4;
  --color-prettylights-syntax-markup-inserted-bg: #033a16;
  --color-prettylights-syntax-markup-changed-text: #ffdfb6;
  --color-prettylights-syntax-markup-changed-bg: #5a1e02;
  --color-prettylights-syntax-markup-ignored-text: #c9d1d9;
  --color-prettylights-syntax-markup-ignored-bg: #1158c7;
  --color-prettylights-syntax-meta-diff-range: #d2a8ff;
  --color-prettylights-syntax-brackethighlighter-angle: #8b949e;
  --color-prettylights-syntax-sublimelinter-gutter-mark: #484f58;
  --color-prettylights-syntax-constant-other-reference-link: #a5d6ff;

  --color-btn-text: rgba(255, 255, 255, 0.9);
  --color-btn-bg: rgba(255, 255, 255, 0.06);
  --color-btn-border: rgba(255, 255, 255, 0.1);
  --color-btn-shadow: 0 0 transparent;
  --color-btn-inset-shadow: 0 0 transparent;
  --color-btn-hover-bg: rgba(255, 255, 255, 0.1);
  --color-btn-hover-border: rgba(255, 255, 255, 0.15);
  --color-btn-active-bg: rgba(255, 255, 255, 0.08);
  --color-btn-active-border: rgba(255, 255, 255, 0.12);
  --color-btn-selected-bg: rgba(58, 170, 231, 0.12);

  --color-btn-primary-text: #fff;
  --color-btn-primary-bg: rgba(58, 170, 231, 0.85);
  --color-btn-primary-border: rgba(58, 170, 231, 0.85);
  --color-btn-primary-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  --color-btn-primary-inset-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
  --color-btn-primary-hover-bg: #3aaae7;
  --color-btn-primary-hover-border: #3aaae7;
  --color-btn-primary-selected-bg: rgba(58, 170, 231, 0.9);
  --color-btn-primary-selected-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.15);
  --color-btn-primary-disabled-text: rgba(255, 255, 255, 0.3);
  --color-btn-primary-disabled-bg: rgba(58, 170, 231, 0.2);
  --color-btn-primary-disabled-border: rgba(58, 170, 231, 0.15);

  --color-action-list-item-default-hover-bg: rgba(255, 255, 255, 0.04);
  --color-segmented-control-bg: rgba(255, 255, 255, 0.04);
  --color-segmented-control-button-bg: #15103a;
  --color-segmented-control-button-selected-border: rgba(255, 255, 255, 0.1);

  --color-fg-default: rgba(255, 255, 255, 0.9);
  --color-fg-muted: rgba(255, 255, 255, 0.45);
  --color-fg-subtle: rgba(255, 255, 255, 0.3);

  --color-canvas-default: rgba(21, 7, 60, 0.5);
  --color-canvas-overlay: rgba(21, 7, 60, 0.88);
  --color-canvas-inset: rgba(255, 255, 255, 0.03);
  --color-canvas-subtle: rgba(255, 255, 255, 0.03);

  --color-border-default: rgba(255, 255, 255, 0.08);
  --color-border-muted: rgba(255, 255, 255, 0.04);
  --color-neutral-muted: rgba(110, 118, 129, 0.2);

  --color-accent-fg: #3aaae7;
  --color-accent-emphasis: #3aaae7;
  --color-accent-muted: rgba(58, 170, 231, 0.3);
  --color-accent-subtle: rgba(58, 170, 231, 0.08);

  --color-success-fg: #3fb950;
  --color-attention-fg: #d29922;
  --color-attention-muted: rgba(187, 128, 9, 0.3);
  --color-attention-subtle: rgba(187, 128, 9, 0.1);
  --color-danger-fg: #f85149;
  --color-danger-muted: rgba(248, 81, 73, 0.3);
  --color-danger-subtle: rgba(248, 81, 73, 0.08);

  --color-primer-shadow-inset: 0 0 transparent;
  --color-scale-gray-7: rgba(255, 255, 255, 0.04);
  --color-scale-blue-8: rgba(58, 170, 231, 0.15);
  --color-social-reaction-bg-hover: var(--color-scale-gray-7);
  --color-social-reaction-bg-reacted-hover: var(--color-scale-blue-8);
}

/* ========== macOS style overrides ========== */
.btn {
  border-radius: 10px !important;
  font-weight: 500 !important;
  letter-spacing: -0.1px;
  transition: background-color 0.12s ease, border-color 0.12s ease, transform 0.1s ease, box-shadow 0.12s ease !important;
}
.btn:hover {
  transform: translateY(-1px) !important;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2) !important;
}
.btn:active {
  transform: scale(0.97) !important;
}
.btn-primary {
  border-radius: 10px !important;
  font-weight: 600 !important;
}
.gsc-comment-box {
  border-radius: 14px !important;
  overflow: hidden !important;
}
.gsc-comment-box-textarea {
  border-radius: 12px !important;
  font-size: 14px !important;
  background: rgba(255, 255, 255, 0.04) !important;
  border-color: rgba(255, 255, 255, 0.1) !important;
  color: rgba(255, 255, 255, 0.9) !important;
}
.gsc-comment-box-textarea:focus {
  border-color: rgba(58, 170, 231, 0.5) !important;
  box-shadow: 0 0 0 3px rgba(58, 170, 231, 0.12) !important;
}
.gsc-comment {
  padding: 14px !important;
  border-radius: 12px !important;
  margin-bottom: 8px !important;
  background: rgba(255, 255, 255, 0.03) !important;
  border: 1px solid rgba(255, 255, 255, 0.04) !important;
}
.gsc-header {
  padding-bottom: 10px !important;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
  margin-bottom: 14px !important;
}
.gsc-timeline {
  gap: 14px !important;
}
.gsc-reactions-button {
  border-radius: 8px !important;
}
.gsc-social-reaction-summary-item {
  border-radius: 20px !important;
}
.Box, .flash {
  border-radius: 12px !important;
}
.form-control {
  border-radius: 10px !important;
}

```
---
> 编辑于2026-08-11

> 作者：Cnkrru

> 联系方式：3253884026@qq.com